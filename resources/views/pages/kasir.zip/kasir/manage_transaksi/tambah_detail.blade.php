@extends('layouts/kasir')

@section('title','Detail Transaksi')

@section('content')

<div class="row">
	<div class="col col-md-6">
		<div class="card shadow">
			<div class="card-header py-3 d-sm-flex align-items-center justify-content-between mb-4">
				<h6 class="m-0 font-weight-bold text-info">Detail Transaksi</h6>
			</div>
			<form method="POST" enctype="multipart/form-data" action="/kasir/tambah_transaksi/detail/upload">
				@csrf
				<input type="hidden" name="id_transaksi" value="{{$transaksi->id_transaksi}}">
				<div class="card-body">
					<div class=" form-group row mb-4">
						<label class="col col-md-4 col-form-label text-md-left">Kode Invoice</label>
						<input type="text" name="nama" value="{{$transaksi->kode_invoice}}" class="form-control col col-md-7" placeholder="Nama Outlet">
					</div>
					<div class=" form-group row mb-4">
						<label class="col col-md-4 col-form-label text-md-left">Paket</label>
						<select class="form-control col col-md-7" name="paket">
							<option selected="" disabled="">Pilih Paket</option>
							@foreach($paket as $data)
							<option value="{{$data->id_paket}}">{{$data->nama_paket}}</option>
							@endforeach
						</select>
					</div>
					<div class=" form-group row mb-4">
						<label class="col col-md-4 col-form-label text-md-left">Jumlah</label>

						<div class=" col col-md-7 ">
							<div class="input-group ">
								<input type="number" class="form-control" name="qty" placeholder="Jumlah" >
								<div class="input-group-append">
									<span class="input-group-text"> Kg </span>
								</div>
							</div>
						</div>
					</div>
					<div class=" form-group row mb-4">
						<label class="col col-md-4 col-form-label text-md-left">Keterangan</label>
						<textarea name="keterangan" class="form-control col col-md-7" placeholder="Keterangan"></textarea>
					</div>
				</div>
				<div class="card-footer">
					<button class="btn btn-primary">Tambah</button>
				</div>
			</form>
		</div>
	</div>
</div>

@endsection
