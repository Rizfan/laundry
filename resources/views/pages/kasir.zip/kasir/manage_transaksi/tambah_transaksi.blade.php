@extends('layouts/kasir')

@section('title','Tambah Transaksi')

@section('content')

<div class="card shadow">
	<div class="card-header py-3 d-sm-flex align-items-center justify-content-between mb-4">
		<h6 class="m-0 font-weight-bold text-info">Tambah Transaksi</h6>
	</div>
	<form method="POST" enctype="multipart/form-data" action="/kasir/tambah_transaksi/upload">
		@csrf
		<div class="card-body">
			<div class="row">
				<div class="col col-md-6">
					<div class=" form-group row mb-4">
						<label class="col col-md-4 col-form-label text-md-left">Kode Invoice</label>
						<input type="text" name="invoice" id="invoice" class="form-control col col-md-7" >
					</div>
					<div class=" form-group row mb-4">
						<label class="col col-md-4 col-form-label text-md-left">Member</label>
						<select class="form-control col col-md-7" name="member">
							<option selected="" disabled="">Pilih Member</option>
							@foreach($member as $data1)
							<option value="{{$data1->id_member}}">{{$data1->nama_member}}</option>
							@endforeach
						</select>
					</div>
					<div class=" form-group row mb-4">
						<label class="col col-md-4 col-form-label text-md-left">Tanggal Transaksi</label>
						<input type="datetime-local" name="tgl_transaksi" class="form-control col col-md-7">
					</div>
					<div class=" form-group row mb-4">
						<label class="col col-md-4 col-form-label text-md-left">Batas Waktu</label>
						<input type="datetime-local" name="batas_waktu" class="form-control col col-md-7">
					</div>
				</div>
				<input type="hidden" name="tanggal" id="tanggal" value="<?php echo date('Ymd') ?>">
				<div class="col col-md-6">
					<div class=" form-group row mb-4">
						<label class="col col-md-4 col-form-label text-md-left">Tanggal Bayar</label>
						<input type="datetime-local" name="tgl_bayar" class="form-control col col-md-7">
					</div>
					<div class=" form-group row mb-4">
						<label class="col col-md-4 col-form-label text-md-left">Biaya Tambahan</label>
						<!-- <input type="number" name="biaya_tambahan" class="form-control col col-md-7" placeholder="Biaya Tambahan"> -->
						<div class=" col col-md-7 ">
							<div class="input-group flex-nowrap ">
								<div class="input-group-prepend">
									<span class="input-group-text">Rp</span>
								</div>
								<input type="number" class="form-control" placeholder="Biaya Tambahan" name="biaya_tambahan">
							</div>
						</div>
					</div>
					<div class=" form-group row mb-4">
						<label class="col col-md-4 col-form-label text-md-left">Diskon</label>
						<!-- <input type="number" name="diskon" class="form-control col col-md-7" placeholder="Diskon"> -->
						<div class=" col col-md-7 ">
							<div class="input-group ">
								<input type="number" class="form-control" name="diskon" placeholder="Diskon" >
								<div class="input-group-append">
									<span class="input-group-text"> % </span>
								</div>
							</div>
						</div>
					</div>
					<div class=" form-group row mb-4">
						<label class="col col-md-4 col-form-label text-md-left">Pajak</label>
						<!-- <input type="number" name="pajak" class="form-control col col-md-7" placeholder="Pajak"> -->
						<div class=" col col-md-7 ">
							<div class="input-group flex-nowrap ">
								<div class="input-group-prepend">
									<span class="input-group-text">Rp</span>
								</div>
								<input type="number" class="form-control" name="pajak" placeholder="Pajak" >
							</div>
						</div>
					</div>
					<div class=" form-group row mb-4">
						<label class="col col-md-4 col-form-label text-md-left">Total</label>
						<!-- <input type="number" name="total" class="form-control col col-md-7" placeholder="Total" disabled=""> -->
						<div class=" col col-md-7 ">
							<div class="input-group flex-nowrap ">
								<div class="input-group-prepend">
									<span class="input-group-text">Rp</span>
								</div>
								<input type="number" class="form-control" name="total" placeholder="Total" disabled="">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="card-footer">
			<button class="btn btn-primary">Tambah</button>
			<a href="/kasir/list_transaksi"  class="btn btn-danger">Batal</a>
		</div>
	</form>
</div>

@endsection

@section('js')
<script language="javascript" type="text/javascript">
	var tanggal = document.getElementById('tanggal').value;
	var campur = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	var panjang = 9;
	var random_all = '';
	for (var i=0; i<panjang; i++) {
		var hasil = Math.floor(Math.random() * campur.length);
		random_all += campur.substring(hasil,hasil+1);
	}
	document.getElementById('invoice').value = "INV/"+tanggal+"/"+random_all;
	
</script>

@endsection